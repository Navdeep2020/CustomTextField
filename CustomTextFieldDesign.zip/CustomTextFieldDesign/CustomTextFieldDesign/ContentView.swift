//
//  ContentView.swift
//  CustomTextFieldDesign
//
//  Created by Navdeep Singh on 10/05/24.
//

import SwiftUI
import CoreData

struct ContentView: View {
    var body: some View {
        @State var title = ""
        
        UITextFieldDesign(text: $title, placeholder: "Enter your name")
            .padding()
    }
}

#Preview {
    ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
