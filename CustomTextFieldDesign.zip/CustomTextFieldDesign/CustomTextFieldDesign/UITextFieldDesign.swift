//
//  UITextFieldDesign.swift
//  CustomTextFieldDesign
//
//  Created by Navdeep Singh on 10/05/24.
//

import SwiftUI
import UIKit
import MDFInternationalization
import MaterialComponents

struct UITextFieldDesign: UIViewRepresentable {
    @Binding var text: String
    var placeholder: String
    
    func makeUIView(context: Context) -> MDCFilledTextField {
        let textField = MDCFilledTextField()
        textField.placeholder = placeholder
        textField.textColor = .darkGray
        return textField
    }
    
    func updateUIView(_ uiView: MDCFilledTextField, context: Context) {
        uiView.text = text
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(text: $text)
    }
    
    class Coordinator: NSObject, UITextFieldDelegate {
        @Binding var text: String
        
        init(text: Binding<String>) {
            _text = text
        }
    }
}

#Preview {
    UITextFieldDesign(text: .constant(""), placeholder: "Navdeep")
}
